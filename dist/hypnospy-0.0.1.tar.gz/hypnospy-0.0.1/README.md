
<img src ="docs/HypnosPy.png" width = "750" class ="center" >

# HypnosPy :sleeping_bed:
A Device-Agnostic, Open-Source Python Software for Wearable Circadian Rhythm and Sleep Analysis and Visualization


# Installation :computer:

Dependencies include python 3.7 and the following packages:


# Usage :bulb:

# Under the hood :mag_right:

# Cite our work! :memo::pencil:

### License :clipboard:
This project is released under a BSD 2-Clause Licence (see LICENCE file)
### Contributions :man_technologist: :woman_technologist:

# Research that uses HypnosPy :rocket:

* 

* 

